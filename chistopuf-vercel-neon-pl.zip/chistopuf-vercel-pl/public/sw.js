const V='cp-v1',OFF='/offline.html';
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll([OFF,'/icon-192.png'])).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
// Cache obejmuje tylko ekran „Brak połączenia”. API, panel i strony prywatne nie są cache’owane.
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.mode!=='navigate'||u.origin!==location.origin||u.pathname.startsWith('/api/')||u.pathname.startsWith('/cabinet'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(OFF)))});
