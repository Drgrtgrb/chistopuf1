-- Необов'язково: сервер сам створює таблиці при першому запиті.
-- Можна виконати вручну в Neon → SQL Editor.
create table if not exists kv(k text primary key,v text not null);
create table if not exists orders(id serial primary key,th text unique not null,idem text unique not null,created bigint not null,status text not null,data text not null,final_price integer,agreed text,note text not null default '',history text not null default '[]');
create table if not exists photos(id serial primary key,oid integer not null,mime text not null,bytes text not null);
create table if not exists bonuses(code text primary key,oid integer not null unique,amount integer not null,exp bigint not null,min integer not null,used integer);
create table if not exists videos(id serial primary key,oid integer not null,mime text not null,bytes text not null);
create table if not exists voices(id serial primary key,oid integer not null,mime text not null,bytes text not null);
create table if not exists sessions(h text primary key,exp bigint not null);
create index if not exists photos_oid on photos(oid);
create index if not exists videos_oid on videos(oid);
create index if not exists voices_oid on voices(oid);
