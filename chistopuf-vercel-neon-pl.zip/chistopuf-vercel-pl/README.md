# ChistoPuf — Vercel + Neon

Strona (public/), API (api/index.js + lib/) i baza danych Neon (Postgres). Zgłoszenia, panel właściciela `/cabinet`, powiadomienia w Telegramie / Viberze / WhatsAppie / e-mailem.

## Co jest w archiwum
- `public/` — strona klienta, panel (`cabinet.html`), ikony, PWA.
- `api/index.js` — jedna funkcja serwerowa Vercel (wszystkie adresy `/api/...`).
- `lib/core.js`, `lib/db.js` — logika i warstwa bazy (Neon, a bez `DATABASE_URL` — lokalny SQLite).
- `vercel.json` — ustawienia Vercel. `schema.sql` — tabele (tworzą się same, plik jest opcjonalny).
- `server.js`, `test.js` — uruchomienie lokalne i test (`node server.js`, Node 22.5+).
- `.env.example` — jakie zmienne są potrzebne.

## Uruchomienie krok po kroku
1. **Neon.** https://neon.tech → zaloguj się → Create project. Na stronie projektu kliknij **Connect** i skopiuj **Connection string** (zaczyna się od `postgresql://`). To jest `DATABASE_URL`.
2. **GitHub.** Utwórz repozytorium na https://github.com/new. Rozpakuj archiwum i wgraj **zawartość** folderu (api, lib, public, package.json, vercel.json …) do katalogu głównego repozytorium: Add file → Upload files → Commit changes. Folderu `node_modules` wgrywać nie trzeba.
3. **Vercel.** https://vercel.com/new → zaimportuj repozytorium. Przed Deploy otwórz **Environment Variables** i dodaj:
   - `DATABASE_URL` — ciąg z Neon;
   - `OWNER_PASSWORD` — Twoje hasło do panelu (min. 8 znaków).
   Kliknij **Deploy**.
4. Otwórz `https://twoja-strona.vercel.app/cabinet` i zaloguj się hasłem `OWNER_PASSWORD`. Zakładka **Powiadomienia** — podłącz Telegram, Viber, WhatsApp, e-mail i wyślij wiadomość testową.

`OWNER_PASSWORD` jest pobierane jednorazowo, przy pierwszym żądaniu. Hasło można potem zmienić w panelu, zmienna na Vercel już na nie nie wpłynie.

## Ograniczenia Vercel (ważne)
- **Wideo klienta — do 4 MB.** Vercel nie przyjmuje żądań większych niż 4,5 MB, dlatego limit wideo obniżono z 25 do 4 MB (w interfejsie również). Zdjęcia i głos działają: zdjęcia są kompresowane w przeglądarce.
- Po nowym zgłoszeniu funkcja czeka na wysłanie powiadomień do 9 sekund, potem odpowiada klientowi.
- Limit częstotliwości żądań jest trzymany w pamięci funkcji i działa orientacyjnie, nie dokładnie.
- Plan Vercel Hobby jest przeznaczony do użytku niekomercyjnego. Dla biznesu sprawdź warunki lub wybierz plan płatny.
- WhatsApp działa przez Meta Business API (obowiązują ograniczenia Meta dotyczące wiadomości).

## Test
Pakiet sprawdzono testami automatycznymi (`node test.js`): na SQLite i na prawdziwym PostgreSQL 16 (transport Neon w teście zastąpiono lokalnym zamiennikiem). Sam sterownik Neon i środowisko Vercel nie są objęte tym testem: pierwszy deploy może wymagać drobnych poprawek.

## Wersja polska
Domyślnie: nazwa ChistoPuf, waluta zł, przykładowe ceny (sofa 3-os. 280 zł, minimum 160 zł, dojazd 40 zł). Wszystko zmienisz w panelu → Firma / Ceny. Teksty zostały przetłumaczone automatycznie — warto je przejrzeć z osobą mówiącą po polsku.
