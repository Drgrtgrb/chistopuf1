'use strict';
// Uruchomienie lokalne / VPS: node server.js (bez DATABASE_URL — SQLite, z nim — Neon).
const http=require('node:http'),{handle}=require('./lib/core');
const PORT=+process.env.PORT||3000;
http.createServer((req,res)=>handle(req,res,true)).listen(PORT,()=>console.log('Serwer: http://localhost:'+PORT+'  Panel: /cabinet'));
