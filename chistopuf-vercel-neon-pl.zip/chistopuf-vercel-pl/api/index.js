'use strict';
// Jedna funkcja Vercel: wszystkie /api/* przez rewrite w vercel.json.
const {handle}=require('../lib/core');
module.exports=(req,res)=>handle(req,res,false);
